#include <stdint.h>
#include <string.h>

#include "message_manager.h"


int message_init_manager(message_manager_t* mgr) {
    int rc = 0;

    return rc;
}

int message_deinit_manager(message_manager_t* mgr) {
    int rc = 0;

    return rc;
}

int has_message(message_manager_t* mgr) {
    int rc = 0;

    return rc;
}

int message_retrieve(message_manager_t* mgr, uint8_t* buffer, int nbr_bytes) {
    char msg[] = "MSG_RETRIEVED";
    int msg_len = sizeof(msg) > nbr_bytes ? nbr_bytes : sizeof(msg);
    strncpy(buffer, msg, msg_len);

    return msg_len;
}

int message_delivery(message_manager_t* mgr, uint8_t* buffer, int nbr_bytes) {
    return nbr_bytes;
}

