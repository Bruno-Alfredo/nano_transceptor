
#include <stdio.h>
#include <string.h>

#include "sm_rocket.h"
#include "radio.h"
#include "event.h"


#define BUFFER_SIZE 3

//char g_buffer[BUFFER_SIZE];
uint8_t g_buffer1[MAX_PACKET_SIZE];

const char MQ_NAME_DOWN[] = "/rocket_down_mq2";
const char MQ_NAME_UP[] = "/rocket_up_mq2";


static THD_WORKING_AREA(waThread1, 32);
static THD_FUNCTION(Thread1, arg) {

  (void)arg;
  chRegSetThreadName("Thread1");
 
        while (1) {
         Si446x_RX(CHANNEL);
         chThdSleepMilliseconds(500);

        #if !SI446X_FIXED_LENGTH
           uint8_t len = 0;
           Si446x_read(&len, 1);
        #else
           uint8_t len = SI446X_FIXED_LENGTH;
        #endif
         if (len != 0){
           Si446x_read((uint8_t*)g_buffer1, len);     //len < MAX_PACKET_SIZE se não o arduino congela                                     
          // sdRead(&SD1, g_buffer1, 1);     // buffer[0] =='E' 'A'   buffer[3] =0;
           if(g_buffer1[0] == 'A') {
              event_post(&g_event_mgr, EV_ACK);
          }else if(g_buffer1[0] == 'E') {
              event_post(&g_event_mgr, EV_EOT);
          }else {
            event_post(&g_event_mgr, EV_DADOS);
                //        palTogglePad(LED_PORT, LED_PAD);
          }
         }
           chThdSleepMilliseconds(10);
        }
}

// TIME_S2i mS2I uS2I I2S
int radio_init(radio_t* radio) {
    int rc = 0;
    sdStart(&SD1, NULL);
    spiStart(&SPID1, &spiCfg);
    palSetPadMode(IOPORT2, 0, PAL_MODE_OUTPUT_PUSHPULL);            //PB0,LED
    palSetPadMode(IOPORT2, SPI1_SS, PAL_MODE_OUTPUT_PUSHPULL);      //PB2
    palSetPadMode(IOPORT2, SPI1_MOSI, PAL_MODE_OUTPUT_PUSHPULL);    //PB3
    palSetPadMode(IOPORT2, SPI1_MISO, PAL_MODE_INPUT);              //PB4
    palSetPadMode(IOPORT2, SPI1_SCK, PAL_MODE_OUTPUT_PUSHPULL);     //PB5
    palSetPadMode(IOPORT2, 1, PAL_MODE_OUTPUT_PUSHPULL);            //1, SDN (reset)

    palClearPad(IOPORT2, 1);
    Si446x_init();

    chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO-1, Thread1, NULL);
    
    return rc;
}

int radio_deinit(radio_t* radio) {
    int rc = 0;

    return rc;
}

int radio_send(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;
    sdWrite(&SD1, (const uint8_t*) buffer, nbr_bytes);
    Si446x_TX((uint8_t*)buffer, nbr_bytes, CHANNEL, SI446X_STATE_RX);
    return rc;
}

int radio_receive(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;

    return rc;
}

void radio_make_silent(radio_t* mgr) {
}
