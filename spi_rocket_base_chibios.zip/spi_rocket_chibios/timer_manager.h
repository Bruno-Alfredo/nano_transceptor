#ifndef timer_manager_H
#define timer_manager_H

#include <stdint.h>


typedef struct timer_manager_struct timer_manager_t;
typedef void (*timer_cb_t)(uint8_t);

int timer_init_manager(timer_manager_t* mgr, uint8_t nbr_timers, timer_cb_t cb);
int timer_deinit_manager(timer_manager_t* mgr);
int timer_set(timer_manager_t* mgr, uint8_t timer_id, uint16_t sec, uint8_t event);
int timer_reset(timer_manager_t* mgr, uint8_t timer_id);

/*#ifdef __linux__
#include "timer_manager_linux.h"
#elif defined __AVR__    */
#include "timer_manager_chibios.h"
//#endif

#endif /* timer_manager_H */
