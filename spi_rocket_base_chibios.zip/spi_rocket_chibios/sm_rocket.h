#ifndef SM_ROCKET_H
#define SM_ROCKET_H

#include "ch.h"
#include "hal.h"

#include "event.h"
#include "timer_manager.h"
#include "message_manager.h"
#include "radio.h"
#include "chvt.h"
#include "chprintf.h"

#include "Si446x.h"

typedef enum {
    ST_INIT = 0, ST_WAIT_ACK, ST_SENDING_DATA, ST_RECEIVING_DATA
} estados;

typedef enum {
    EV_ACK = EV_USER, EV_SOT, EV_TOUT_SOT, EV_TOUT_SESSION_TX, EV_TOUT_NO_RX, 
    EV_TOUT_SESSION_RX, EV_EOT, EV_DADOS, EV_DATA_SENT, EV_MAX
} eventos;

static const SPIConfig spiCfg = {
  NULL,                         /* SPI callback.                  */
  IOPORT2,                      /* SPI chip select port.          */
  SPI1_SS,                            /* SPI chip select pad.           */
  SPI_CR_DORD_MSB_FIRST     |   /* SPI Data order.                */
  SPI_CR_CPOL_CPHA_MODE(0)  |   /* SPI clock polarity and phase.  */
  SPI_CR_SCK_FOSC_64,          /* SPI clock.                     */
  SPI_SR_SCK_FOSC_2             /* SPI double speed bit.          */
};

#define SOT_TIMER_ID 0
#define DOWNLINK_TIMER_ID 0
#define UPLINK_TIMER_ID 0
#define UPLINK_RX_TIMER_ID 1

#define LED_PAD PORTB_LED1
#define LED_PORT IOPORT2

#define CHANNEL 0
#define MAX_PACKET_SIZE 64


extern estados g_state;
extern timer_manager_t g_timer_mgr;
extern message_manager_t g_msg_mgr;
extern radio_t g_radio;
extern event_manager_t g_event_mgr;

virtual_timer_t vt_obj1;
virtual_timer_t vt_obj2;
virtual_timer_t vt_obj3;

void send_sot();
void send_eot();
void send_first_data();
void send_data();
void processa_dados();
void tout_rx_sessao();

void init_sm();
void processa_evento(event_t input);

#endif /* SM_ROCKET_H */
