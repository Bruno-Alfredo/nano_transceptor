#ifndef RADIO_H
#define RADIO_H

#include <stdint.h>

typedef struct radio_struct radio_t;

int radio_init(radio_t* radio);
int radio_deinit(radio_t* radio);
int radio_send(radio_t*, const uint8_t[], int);
int radio_receive(radio_t*, const uint8_t[], int);
void radio_make_silent(radio_t*);

/*#ifdef __linux__
#include "radio_linux.h"
#elif defined __AVR__   */
#include "radio_chibios.h"
//#endif

#endif /* RADIO_H */
