#include "ch.h"
#include "hal.h"

#include <stdio.h>
#include "event.h"

int event_init_manager(event_manager_t* mgr) {
    int rc = 0;
    chSemObjectInit(&mgr->_sync, 0);
   /* if(rc = sem_init(&mgr->_sync, 0, 0)) {
        perror("On creating event semaphore:");
    }  */

    return rc;
}

int event_deinit_manager(event_manager_t* mgr) {
 /*   if(sem_destroy(&mgr->_sync))  {
        perror("On destroying the semaphore");
        return -1;
    } */
    return 0;
}


void event_post(event_manager_t* mgr, event_t ev) {
    mgr->_event = ev;
    chSemSignal(&mgr->_sync);
}

event_t event_wait(event_manager_t* mgr) {
    chSemWait(&mgr->_sync);
    return mgr->_event;
}
