#ifndef EVENT_CHIBIOS_H
#define EVENT_CHIBIOS_H

#include "ch.h"
#include "hal.h"

struct event_manager_struct {
    event_t _event;
    semaphore_t _sync;
};

#endif /* EVENT_CHIBIOS_H */
