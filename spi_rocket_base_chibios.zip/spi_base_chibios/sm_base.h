#ifndef SM_BASE_H
#define SM_BASE_H

#include "ch.h"
#include "hal.h"


static const SPIConfig spiCfg = {
  NULL,                         /* SPI callback.                  */
  IOPORT2,                      /* SPI chip select port.          */
  SPI1_SS,                            /* SPI chip select pad.           */
  SPI_CR_DORD_MSB_FIRST     |   /* SPI Data order.                */
  SPI_CR_CPOL_CPHA_MODE(0)  |   /* SPI clock polarity and phase.  */
  SPI_CR_SCK_FOSC_128,          /* SPI clock.                     */   
  SPI_SR_SCK_FOSC_2,             /* SPI double speed bit.          */
  SPI_ROLE_MASTER
};

//FOSC_128 = 250kHz

typedef enum {
    ST_INIT = 0, ST_WAIT_SOT, ST_WAIT_DATA, ST_SEND_DATA
} estados;

typedef enum {
 EV_ACK = 0, EV_SOT, EV_TOUT_SOT, EV_TOUT, EV_EOT, EV_EOT_BASE, EV_DATA_RECEIVED,
    EV_SEND_DATA_ROCKET,EV_SEND_DATA_BASE, EV_TOUT_NO_RX, EV_NO_DATA, EV_TOUT_SESSAO,
    EV_INVALID, EV_MAX
} eventos;



extern estados g_state;

void init_sm();
int processa_sot();
void processa_tout_sot();
void processa_tout();
void processa_eot_base();
void processa_eot_rocket();
void processa_send_data();
void processa_no_data();
void processa_send_data_base();
void processa_send_data_base_begin();
void processa_dados();
void tout_sessao();
void unexpected_sot();

void processa_evento(eventos input);

#endif /* SM_BASE_H */
